const appErrors = { db_connect_fail: 2 };

module.exports = appErrors;
