/**
 * GET /uploads/upload
 * File Upload API example.
 */

exports.getFileUpload = (req, res) => {
  res.render("/", {
    title: "File Upload"
  });
};

exports.postFileUpload = (req, res) => {
  req.flash("success", "File was uploaded successfully.");
  res.redirect("/");
};
